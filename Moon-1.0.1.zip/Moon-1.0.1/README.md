# <p align=center>Moon 🌙</p>

<h6 align=center> Fast and small application to Generate mutliple discord for free</h6>



<p align=center>Enjoy? Star this repo ⭐</p>






# Features
- Nitro code generator


- Nitro code checker

- Nitro code sniper (enable in versions/config.py)


- Invite gen


- Invite checker


- Proxys (enable in versions/config.py)



- Webhook notif (enable in versions/config.py)


-  Discord token checker & gen. (enable in versions/config.py)


# Usage


**Also note python3 is required to use this.**

RUN: ```git clone https://github.com/7ua/Moon && cd Moon && cd versions && python3 new.py```

**MUST CHECK CONFIG.PY**





# run on ios & android



First go to replit.com


Then make a new python project


go to the terminal in the project and type ```git clone https://github.com/7ua/Moon && cd Moon && cd versions && python3 new.py```

Now press run! Should work!


# Upcoming Features

- None for now.


# Contributors

#### Owner 

Github.com/7ua


#### Normal Contributors, Thank you to anyone to Contributes.



Github.com/committt


Github.com/n1ssan


Github.com/PASS90


